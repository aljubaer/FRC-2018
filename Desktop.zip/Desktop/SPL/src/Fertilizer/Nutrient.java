package Fertilizer;

public class Nutrient {
	
	public String name;
	public double amount;
	Database db = new Database();
	//double testValue, requiredNutrient;
	
}
